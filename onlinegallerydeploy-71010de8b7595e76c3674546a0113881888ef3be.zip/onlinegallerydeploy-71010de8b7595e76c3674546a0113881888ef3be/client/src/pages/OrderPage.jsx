const OrderPage = () => {
    return (
      <div>
        <h1>Order Page</h1>
        {/* Your component code here */}
      </div>
    );
  };
  
  export default OrderPage;
  